cd /home/soleil/WWW/htmdev/js/libs/

./Jsmin <validator.js> validator.min.js "JP laroche 2016/08/17"
./Jsmin <validatorfunc.js> validatorfunc.min.js "JP laroche 2016/08/17"
./Jsmin <ecr00.js> ecr00.min.js "JP laroche 2016/08/17"


./Jsmin <prototype.js> prototype.min.js "JP laroche 2016/08/17"
./Jsmin <window.js> window.min.js "JP laroche 2016/08/17"
./Jsmin <effects.js> effects.min.js "JP laroche 2016/08/17"
./Jsmin <window_effects.js> window_effects.min.js "JP laroche 2016/08/17"

./Jsmin <XMLWriter.js> XMLWriter.min.js "JP laroche 2016/08/17"
exit 0